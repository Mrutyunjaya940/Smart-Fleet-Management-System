export interface Driver {

  id: number;

  name: string;

  phone: string;

  licenseNumber: string;

  assignedVehicle: string;

  status: 'Available' | 'On Trip' | 'Off Duty';

}
