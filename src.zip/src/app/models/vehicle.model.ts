export interface Vehicle {
  id: number;
  vehicleNumber: string;
  type: string;
  driverName: string;
  capacity: string;
  status: string;
}
