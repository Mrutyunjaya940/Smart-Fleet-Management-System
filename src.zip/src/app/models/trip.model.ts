export interface Trip {

  id: number;

  tripId: string;

  vehicle: string;

  driver: string;

  route: string;

  distance: number;

  speed: number;

  eta: string;

  progress: number;

  status: 'Active' | 'Completed' | 'Delayed';

}
