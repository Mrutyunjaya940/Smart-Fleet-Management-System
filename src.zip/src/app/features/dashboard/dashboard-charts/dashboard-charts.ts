import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BaseChartDirective } from 'ng2-charts';

import {
  ChartConfiguration,
  ChartOptions,
  ChartType
} from 'chart.js';

import {
  Chart,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip
} from 'chart.js';

Chart.register(
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip
);

@Component({
  selector: 'app-dashboard-charts',
  standalone: true,
  imports: [
    CommonModule,
    BaseChartDirective
  ],
  templateUrl: './dashboard-charts.html',
  styleUrls: ['./dashboard-charts.css']
})
export class DashboardCharts {

  // -----------------------
  // Pie Chart
  // -----------------------

  //pieChartType: ChartType = 'pie';

  pieChartData: ChartConfiguration<'pie'>['data'] = {

    labels: [
      'Active',
      'Maintenance',
      'Inactive'
    ],

    datasets: [

      {

        data: [95,18,7],

        backgroundColor: [

          '#4CAF50',
          '#FF9800',
          '#F44336'

        ]

      }

    ]

  };

  pieChartOptions: ChartOptions<'pie'> = {

    responsive: true,

    plugins: {

      legend: {

        position: 'bottom'

      }

    }

  };

  // -----------------------
  // Bar Chart
  // -----------------------

  //barChartType: ChartType = 'bar';

  barChartData: ChartConfiguration<'bar'>['data'] = {

    labels: [

      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun'

    ],

    datasets: [

      {

        label: 'Trips',

        data: [

          80,
          95,
          120,
          110,
          150,
          175

        ],

        backgroundColor: '#2563EB'

      }

    ]

  };

  barChartOptions: ChartOptions<'bar'> = {

    responsive: true

  };

}
