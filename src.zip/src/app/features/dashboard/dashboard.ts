import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardCharts } from './dashboard-charts/dashboard-charts';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    DashboardCharts
  ],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class Dashboard {

}
