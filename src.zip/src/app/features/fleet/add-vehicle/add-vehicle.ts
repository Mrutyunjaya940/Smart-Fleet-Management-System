import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';

import { Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-add-vehicle',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule
  ],
  templateUrl: './add-vehicle.html',
  styleUrls: ['./add-vehicle.css']
})
export class AddVehicle {

  vehicle = {
    vehicleNumber: '',
    type: '',
    driverName: '',
    capacity: '',
    status: 'Active'
  };

  constructor(
    private dialogRef: MatDialogRef<AddVehicle>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {

    if (data) {
      this.vehicle = { ...data };
    }

  }

  save() {

    if (
      !this.vehicle.vehicleNumber ||
      !this.vehicle.type ||
      !this.vehicle.driverName ||
      !this.vehicle.capacity
    ) {
      alert('Please fill in all required fields.');
      return;
    }

    this.dialogRef.close(this.vehicle);

  }
  close() {
    this.dialogRef.close();
  }

}
