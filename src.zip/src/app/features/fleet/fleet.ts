import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { Vehicle } from '../../models/vehicle.model';

import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { AddVehicle } from './add-vehicle/add-vehicle';

@Component({
  selector: 'app-fleet',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule
  ],
  templateUrl: './fleet.html',
  styleUrls: ['./fleet.css']
})
export class Fleet implements OnInit {

  displayedColumns: string[] = [
    'vehicleNumber',
    'type',
    'driverName',
    'capacity',
    'status',
    'actions'
  ];

  dataSource = new MatTableDataSource<Vehicle>([]);

  constructor(private dialog: MatDialog) {}
  ngOnInit(): void {

    const mockVehicles: Vehicle[] = [

      {
        id: 1,
        vehicleNumber: 'OD-02-AB-1234',
        type: 'Truck',
        driverName: 'Bana',
        capacity: '10 Tons',
        status: 'Active'
      },

      {
        id: 2,
        vehicleNumber: 'OD-02-CD-5678',
        type: 'Van',
        driverName: 'Litu',
        capacity: '2 Tons',
        status: 'Maintenance'
      },

      {
        id: 3,
        vehicleNumber: 'OD-33-EF-9012',
        type: 'Truck',
        driverName: 'Unassigned',
        capacity: '15 Tons',
        status: 'Available'
      }

    ];

    this.dataSource.data = mockVehicles;
  }

  applyFilter(event: Event): void {

    const filterValue = (event.target as HTMLInputElement).value;

    this.dataSource.filter = filterValue.trim().toLowerCase();

  }

  addVehicle(): void {

    const dialogRef = this.dialog.open(AddVehicle, {
      width: '600px'
    });

    dialogRef.afterClosed().subscribe(result => {

      if (result) {

        const newVehicle: Vehicle = {
          id: this.dataSource.data.length + 1,
          vehicleNumber: result.vehicleNumber,
          type: result.type,
          driverName: result.driverName,
          capacity: result.capacity,
          status: result.status
        };

        this.dataSource.data = [
          ...this.dataSource.data,
          newVehicle
        ];

      }

    });

  }

  editVehicle(vehicle: Vehicle): void {

    const dialogRef = this.dialog.open(AddVehicle, {
      width: '600px',
      data: vehicle
    });

    dialogRef.afterClosed().subscribe(result => {

      if (result) {

        const index = this.dataSource.data.findIndex(v => v.id === vehicle.id);

        if (index !== -1) {

          this.dataSource.data[index] = {
            ...vehicle,
            ...result
          };

          // Refresh the Material table
          this.dataSource.data = [...this.dataSource.data];
        }

      }

    });

  }

  deleteVehicle(vehicle: Vehicle): void {

    const confirmed = confirm(
      `Are you sure you want to delete vehicle "${vehicle.vehicleNumber}"?`
    );

    if (!confirmed) {
      return;
    }

    this.dataSource.data = this.dataSource.data.filter(
      v => v.id !== vehicle.id
    );

  }

}
