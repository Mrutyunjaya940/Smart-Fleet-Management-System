import { Component , OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder , FormGroup} from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { inject } from '@angular/core';

@Component({
  selector: 'app-route-optimization',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './route-optimization.html',
  styleUrls: ['./route-optimization.css']
})
export class RouteOptimization implements OnInit {

  routeForm!: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {

    this.routeForm = this.fb.group({

      source: ['Warehouse'],

      destination: ['Airport'],

      vehicle: ['OD-02-AB-1234']

    });

  }

}
  distance = '24.5 km';

  eta = '38 Minutes';

  fuel = '3.4 Liters';

  traffic = 'Low';

  optimizeRoute() {

    console.log('Optimizing Route');

  }

}
