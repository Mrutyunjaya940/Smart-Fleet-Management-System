import * as L from 'leaflet';
import { Component, OnInit, AfterViewInit } from '@angular/core';

import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { BaseChartDirective } from 'ng2-charts';
//import { BaseChartDirective } from 'ng2-charts';
import { NgxGaugeModule } from 'ngx-gauge';

import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

import {
  BarElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip,
  ChartConfiguration,
  ChartOptions,
  ChartType
} from 'chart.js';

import { Fuel } from '../../../models/fuel.model';

Chart.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Legend,
  Tooltip
);
@Component({
  selector: 'app-fuel-management',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule,
    BaseChartDirective,
    NgxGaugeModule,
  ],

  templateUrl: './fuel-management.html',
  styleUrls: ['./fuel-management.css']
})
export class FuelManagement implements OnInit, AfterViewInit {
  displayedColumns: string[] = [
    'vehicle',
    'driver',
    'liters',
    'totalCost',
    'mileage',
    'station',
    'date',
    'actions'
  ];
  map!: L.Map;

  ngAfterViewInit(): void {

    setTimeout(() => {
      this.initializeFuelMap();
    }, 200);

  }
  initializeFuelMap(): void {

    this.map = L.map('fuelMap').setView(
      [20.2961, 85.8245],
      13
    );

    L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: '© OpenStreetMap',
        maxZoom: 19
      }
    ).addTo(this.map);

    this.addFuelStations();

  }
  addFuelStations(): void {

    const stations = [

      {
        name: 'Indian Oil',
        lat: 20.2961,
        lng: 85.8245
      },

      {
        name: 'HP Petrol',
        lat: 20.2890,
        lng: 85.8340
      },

      {
        name: 'Bharat Petroleum',
        lat: 20.3015,
        lng: 85.8150
      },

      {
        name: 'Shell',
        lat: 20.3070,
        lng: 85.8420
      }

    ];

    stations.forEach(station => {

      L.marker([
        station.lat,
        station.lng
      ])
        .addTo(this.map)
        .bindPopup(`<b>${station.name}</b>`);

    });

  }
  dataSource = new MatTableDataSource<Fuel>();

  fuelLogs: Fuel[] = [];

  topVehicles = [
    {
      vehicle: 'OD-02-AB-1234',
      driver: 'Rahul Kumar',
      efficiency: 96
    },
    {
      vehicle: 'OD-05-CD-5678',
      driver: 'Amit Das',
      efficiency: 91
    },
    {
      vehicle: 'OD-10-EF-9012',
      driver: 'Prakash Rout',
      efficiency: 87
    }
  ];

  // Temporary chart placeholders
  barChartData: ChartConfiguration<'bar'>['data'] = {

    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],

    datasets: [

      {
        label: 'Fuel Cost (₹)',

        data: [4200, 5200, 4800, 6100, 5900, 6400],

        backgroundColor: [
          '#2563eb',
          '#3b82f6',
          '#10b981',
          '#22c55e',
          '#f59e0b',
          '#ef4444'
        ],

        borderRadius: 10,

        borderSkipped: false
      }

    ]

  };

  barChartOptions: ChartOptions<'bar'> = {

    responsive: true,

    maintainAspectRatio: false,

    plugins: {

      legend: {

        display: false

      }

    },

    scales: {

      x: {

        grid: {

          display: false

        }

      },

      y: {

        beginAtZero: true,

        ticks: {

          stepSize: 1000

        }

      }

    }

  };
  ngOnInit(): void {

    this.fuelLogs = [

      {
        id:1,
        vehicle:'OD-02-AB-1234',
        driver:'Rahul Kumar',
        station:'Indian Oil',
        liters:42,
        pricePerLiter:100,
        totalCost:4200,
        mileage:15.2,
        odometer:32560,
        paymentMethod:'Card',
        date:'08 Aug 2026'
      },

      {
        id:2,
        vehicle:'OD-05-CD-5678',
        driver:'Amit Das',
        station:'HP Petrol',
        liters:55,
        pricePerLiter:99,
        totalCost:5445,
        mileage:13.4,
        odometer:45200,
        paymentMethod:'Cash',
        date:'07 Aug 2026'
      },

      {
        id:3,
        vehicle:'OD-10-EF-9012',
        driver:'Prakash Rout',
        station:'Bharat Petroleum',
        liters:48,
        pricePerLiter:101,
        totalCost:4848,
        mileage:14.8,
        odometer:28900,
        paymentMethod:'UPI',
        date:'06 Aug 2026'
      }

    ];

    this.dataSource.data = this.fuelLogs;

  }

  applyFilter(event: Event): void {

    const value = (event.target as HTMLInputElement)
      .value
      .trim()
      .toLowerCase();

    this.dataSource.filter = value;

  }

  addFuel(): void {

    console.log('Add Fuel');

  }

  editFuel(fuel: Fuel): void {

    console.log('Edit', fuel);

  }

  deleteFuel(fuel: Fuel): void {

    this.fuelLogs = this.fuelLogs.filter(
      f => f.id !== fuel.id
    );

    this.dataSource.data = this.fuelLogs;

  }

  get totalFuel(): number {

    return this.fuelLogs.reduce(
      (sum, fuel) => sum + fuel.liters,
      0
    );

  }

  get totalCost(): number {

    return this.fuelLogs.reduce(
      (sum, fuel) => sum + fuel.totalCost,
      0
    );

  }

  get averageMileage(): number {

    if (!this.fuelLogs.length) return 0;

    const total = this.fuelLogs.reduce(
      (sum, fuel) => sum + fuel.mileage,
      0
    );

    return Number(
      (total / this.fuelLogs.length).toFixed(1)
    );

  }

  get lowFuelAlerts(): number {

    return 3;

  }

}
