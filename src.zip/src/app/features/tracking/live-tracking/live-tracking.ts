import { Component, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import * as L from 'leaflet';

import { VehicleLocation } from '../../../models/location.model';

@Component({
  selector: 'app-live-tracking',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './live-tracking.html',
  styleUrls: ['./live-tracking.css']
})
export class LiveTracking implements AfterViewInit {

  map!: L.Map;
  markers: L.Marker[] = [];

  vehicles: VehicleLocation[] = [

    {
      id: 1,
      vehicleNumber: 'OD-02-AB-1234',
      driver: 'Rahul Kumar',
      latitude: 20.2961,
      longitude: 85.8245,
      speed: 65,
      status: 'Moving'
    },

    {
      id: 2,
      vehicleNumber: 'OD-05-CD-5678',
      driver: 'Amit Das',
      latitude: 20.2855,
      longitude: 85.8402,
      speed: 0,
      status: 'Idle'
    },

    {
      id: 3,
      vehicleNumber: 'OD-14-GH-3456',
      driver: 'Suresh Nayak',
      latitude: 20.3025,
      longitude: 85.8154,
      speed: 0,
      status: 'Offline'
    },

    {
      id: 4,
      vehicleNumber: 'OD-10-EF-9012',
      driver: 'Prakash Rout',
      latitude: 20.2915,
      longitude: 85.8320,
      speed: 42,
      status: 'Moving'
    }

  ];

  ngAfterViewInit(): void {

    this.initializeMap();

    this.simulateMovement();

  }

  initializeMap(): void {

    this.map = L.map('map').setView(
      [20.2961, 85.8245],
      13
    );

    L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        maxZoom: 19
      }
    ).addTo(this.map);

    this.addMarkers();

  }

  addMarkers(): void {

    this.markers = [];

    this.vehicles.forEach(vehicle => {

      const marker = L.marker([
        vehicle.latitude,
        vehicle.longitude
      ]).addTo(this.map);

      marker.bindPopup(`
      <b>${vehicle.vehicleNumber}</b><br>
      Driver: ${vehicle.driver}<br>
      Status: ${vehicle.status}<br>
      Speed: ${vehicle.speed} km/h
    `);

      this.markers.push(marker);

    });

  }
  simulateMovement(): void {

    setInterval(() => {

      this.vehicles.forEach((vehicle, index) => {

        if (vehicle.status === 'Moving') {

          vehicle.latitude += (Math.random() - 0.5) * 0.01;
          vehicle.longitude += (Math.random() - 0.5) * 0.01;

          vehicle.speed = Math.floor(Math.random() * 30) + 40;

          this.markers[index].setLatLng([
            vehicle.latitude,
            vehicle.longitude
          ]);

          const popupContent = `
        <b>${vehicle.vehicleNumber}</b><br>
         Driver: ${vehicle.driver}<br>
        Status: ${vehicle.status}<br>
        Speed: ${vehicle.speed} km/h
`     ;

          this.markers[index].setPopupContent(popupContent);

          if (this.markers[index].isPopupOpen()) {
            this.markers[index].openPopup();
          }

        }

      });

    }, 3000);

  }

  get movingCount(): number {
    return this.vehicles.filter(vehicle => vehicle.status === 'Moving').length;
  }

  get idleCount(): number {
    return this.vehicles.filter(vehicle => vehicle.status === 'Idle').length;
  }

  get offlineCount(): number {
    return this.vehicles.filter(vehicle => vehicle.status === 'Offline').length;
  }


}
