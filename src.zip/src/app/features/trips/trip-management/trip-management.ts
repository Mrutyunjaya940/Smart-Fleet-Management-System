import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { Trip } from '../../../models/trip.model';

@Component({
  selector: 'app-trip-management',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule
  ],
  templateUrl: './trip-management.html',
  styleUrls: ['./trip-management.css']
})
export class TripManagement implements OnInit {

  trips: Trip[] = [];

  filteredTrips: Trip[] = [];

  ngOnInit(): void {

    this.trips = [

      {
        id: 1,
        tripId: 'TRP-001',
        vehicle: 'OD-02-AB-1234',
        driver: 'Rahul Kumar',
        route: 'Bhubaneswar → Cuttack',
        distance: 28,
        speed: 62,
        eta: '20 min',
        progress: 65,
        status: 'Active'
      },

      {
        id: 2,
        tripId: 'TRP-002',
        vehicle: 'OD-05-CD-5678',
        driver: 'Amit Das',
        route: 'Puri → Khordha',
        distance: 52,
        speed: 45,
        eta: '12 min',
        progress: 82,
        status: 'Active'
      },

      {
        id: 3,
        tripId: 'TRP-003',
        vehicle: 'OD-14-GH-3456',
        driver: 'Suresh Nayak',
        route: 'Balasore → Bhadrak',
        distance: 36,
        speed: 0,
        eta: '-',
        progress: 100,
        status: 'Completed'
      },

      {
        id: 4,
        tripId: 'TRP-004',
        vehicle: 'OD-10-EF-9012',
        driver: 'Prakash Rout',
        route: 'Berhampur → Gopalpur',
        distance: 18,
        speed: 20,
        eta: '35 min',
        progress: 35,
        status: 'Delayed'
      }

    ];

    this.filteredTrips = [...this.trips];

  }

  applyFilter(event: Event): void {

    const value = (event.target as HTMLInputElement)
      .value
      .toLowerCase()
      .trim();

    this.filteredTrips = this.trips.filter(trip =>

      trip.tripId.toLowerCase().includes(value) ||

      trip.vehicle.toLowerCase().includes(value) ||

      trip.driver.toLowerCase().includes(value) ||

      trip.route.toLowerCase().includes(value)

    );

  }

  addTrip(): void {

    console.log('Add Trip');

  }

  viewTrip(trip: Trip): void {

    console.log('View', trip);

  }

  editTrip(trip: Trip): void {

    console.log('Edit', trip);

  }

  deleteTrip(trip: Trip): void {

    this.filteredTrips = this.filteredTrips.filter(t => t.id !== trip.id);

    this.trips = this.trips.filter(t => t.id !== trip.id);

  }

  get totalTrips(): number {

    return this.trips.length;

  }

  get activeTrips(): number {

    return this.trips.filter(t => t.status === 'Active').length;

  }

  get completedTrips(): number {

    return this.trips.filter(t => t.status === 'Completed').length;

  }

  get delayedTrips(): number {

    return this.trips.filter(t => t.status === 'Delayed').length;

  }

}
