import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';

import {
  MatDialogRef,
  MatDialogModule
} from '@angular/material/dialog';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-add-driver-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './add-driver-dialog.html',
  styleUrls: ['./add-driver-dialog.css']
})
export class AddDriverDialog {

  driverForm!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AddDriverDialog>
  ) {

    this.driverForm = this.fb.group({

      name: ['', Validators.required],

      phone: ['', Validators.required],

      licenseNumber: ['', Validators.required],

      assignedVehicle: [''],

      status: ['Available', Validators.required]

    });

  }

  save(): void {

    if (this.driverForm.valid) {

      this.dialogRef.close(this.driverForm.value);

    }

  }

  close(): void {

    this.dialogRef.close();

  }

}
