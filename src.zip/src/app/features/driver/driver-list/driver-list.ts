import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { Driver } from '../../../models/driver.model';
import { AddDriverDialog } from '../add-driver-dialog/add-driver-dialog';

@Component({
  selector: 'app-driver-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule
  ],
  templateUrl: './driver-list.html',
  styleUrls: ['./driver-list.css']
})
export class DriverList implements OnInit {

  displayedColumns: string[] = [
    'name',
    'phone',
    'licenseNumber',
    'assignedVehicle',
    'status',
    'actions'
  ];

  dataSource = new MatTableDataSource<Driver>([]);

  constructor(private dialog: MatDialog) {}

  ngOnInit(): void {

    this.dataSource.data = [

      {
        id:1,
        name:'Rahul Kumar',
        phone:'9876543210',
        licenseNumber:'DL-2024-001',
        assignedVehicle:'OD-02-AB-1234',
        status:'Available'
      },

      {
        id:2,
        name:'Amit Das',
        phone:'9123456789',
        licenseNumber:'DL-2024-002',
        assignedVehicle:'OD-05-CD-5678',
        status:'On Trip'
      },

      {
        id:3,
        name:'Suresh Nayak',
        phone:'9988776655',
        licenseNumber:'DL-2024-003',
        assignedVehicle:'Not Assigned',
        status:'Off Duty'
      }

    ];

  }

  applyFilter(event: Event){

    const filterValue = (event.target as HTMLInputElement).value;

    this.dataSource.filter = filterValue.trim().toLowerCase();

  }

  addDriver() {

    const dialogRef = this.dialog.open(AddDriverDialog, {
      width: '500px'
    });

    dialogRef.afterClosed().subscribe(result => {

      if(result){

        const drivers = this.dataSource.data;

        drivers.push({

          id: drivers.length + 1,

          name: result.name,

          phone: result.phone,

          licenseNumber: result.licenseNumber,

          assignedVehicle: result.assignedVehicle,

          status: result.status

        });

        this.dataSource.data = [...drivers];

      }

    });

  }

  editDriver(driver:Driver){

    console.log(driver);

  }

  deleteDriver(driver:Driver){

    this.dataSource.data =
      this.dataSource.data.filter(d=>d.id!==driver.id);

  }

}
