import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar {

  appName: string = 'Smart VehicleList';
  menus = [

    {
      name: 'Dashboard',
      icon: '🏠',
      route: '/dashboard'
    },

    {
      name: 'Vehicle List',
      icon: '🚚',
      route: '/fleet'
    },

    {
      name: 'Drivers',
      icon: '🧑‍✈️',
      route: '/drivers'
    },

    {
      name: 'Tracking',
      icon: '📍',
      route: '/tracking'
    },
    {
      name: 'Routes',
      icon: '🗺️',
      route: '/routes'
    },

    {
      name: 'Trips',
      icon: '🚛',
      route: '/trips'
    },
    {
      name: 'Fuel',
      icon: '⛽',
      route: '/fuel'
    }

  ];

}
