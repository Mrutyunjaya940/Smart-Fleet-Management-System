//import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { AuthService } from '../../features/authentication/services/auth.service';
//import {  OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule
  ],
  templateUrl: './header.html',
  styleUrl: './header.css'
})

export class Header implements OnInit {
  title: string = 'Smart VehicleList Management';
  isDarkMode = false;
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}
  ngOnInit(): void {

    const savedTheme = localStorage.getItem('theme');

    if (savedTheme === 'dark') {

      this.isDarkMode = true;

      document.body.classList.add('dark-theme');

    }

  }

  toggleTheme(): void {

    this.isDarkMode = !this.isDarkMode;

    if (this.isDarkMode) {

      document.body.classList.add('dark-theme');
      localStorage.setItem('theme', 'dark');

    } else {

      document.body.classList.remove('dark-theme');
      localStorage.setItem('theme', 'light');

    }

  }

  logout() {

    this.authService.logout();

    this.router.navigate(['/login']);

  }

}

