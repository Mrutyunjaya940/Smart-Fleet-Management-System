import { Routes } from '@angular/router';


import { Login } from './features/authentication/login/login';
import { ForgotPassword } from './features/authentication/forgot-password/forgot-password';
import { DashboardLayout } from './layout/dashboard-layout/dashboard-layout';
import { OtpVerification } from './features/authentication/otp-verification/otp-verification';
import { ResetPassword } from './features/authentication/reset-password/reset-password';
import { authGuard } from './features/authentication/guards/auth.guard';
import { Fleet } from './features/fleet/fleet';
import { Dashboard } from './features/dashboard/dashboard';
import { DriverList } from './features/driver/driver-list/driver-list';
import { LiveTracking } from './features/tracking/live-tracking/live-tracking';
import { RouteManagement } from './features/routes/route-management/route-management';
import { TripManagement } from './features/trips/trip-management/trip-management';
import {FuelManagement} from './features/fuel/fuel-management/fuel-management';

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },

  {
    path: 'login',
    component: Login
  },

  {
    path: 'forgot-password',
    component: ForgotPassword
  },

  {
    path: 'otp-verification',
    component: OtpVerification
  },

  {
    path: 'reset-password',
    component: ResetPassword
  },

  {
    path: '',
    component: DashboardLayout,
    canActivate: [authGuard],
    children: [

      {
        path: 'dashboard',
        component: Dashboard
      },

      {
        path: 'fleet',
        component: Fleet
      },
      {
        path: 'drivers',
        component: DriverList
      },
      {
        path: 'tracking',
        component: LiveTracking
      },
      {
        path: 'routes',
        component: RouteManagement
      },
      {
        path: 'trips',
        component: TripManagement
      },
      {
        path: 'fuel',
        component: FuelManagement
      },

    ]
  }

];
